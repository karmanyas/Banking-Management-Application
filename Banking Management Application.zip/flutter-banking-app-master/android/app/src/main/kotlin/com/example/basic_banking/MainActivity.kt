package com.example.basic_banking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
